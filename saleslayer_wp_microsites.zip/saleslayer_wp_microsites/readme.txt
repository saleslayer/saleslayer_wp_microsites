=== SLYR Connector ===

Contributors: Sales Layer Tech Co.
Requires at least: 3.0.1
Tested up to: 5.1.1
Stable tag: 5.1
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html